#!/bin/bash
cd /var/lib/trellodash

python /var/lib/trellodash/runDash.py 
